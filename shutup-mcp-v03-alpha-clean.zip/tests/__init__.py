"""Tests for shutup-mcp."""
